import socket
import threading

# Configurações do servidor
HOST = '127.0.0.1' # Endereço IP do servidor
PORT = 5000         # Porta do servidor

# Lista para armazenar conexões de clientes
clientes = []

def gerenciar_cliente(conexao, endereco):
    print(f"Conexão estabelecida com {endereco}")
    while True:
        try:
            mensagem = conexao.recv(1024).decode('utf-8')
            if mensagem:
                print(f"{endereco} diz: {mensagem}")
                enviar_para_todos(mensagem, conexao)
            else:
                remover_cliente(conexao)
                break
        except:
            remover_cliente(conexao)
            break

def enviar_para_todos(mensagem, conexao_atual):
    for cliente in clientes:
        if cliente != conexao_atual:
            try:
                cliente.send(mensagem.encode('utf-8'))
            except:
                remover_cliente(cliente)

def remover_cliente(conexao):
    if conexao in clientes:
        clientes.remove(conexao)

def iniciar_servidor():
    servidor = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    servidor.bind((HOST, PORT))
    servidor.listen()
    print(f"Servidor rodando em {HOST}:{PORT}")

    while True:
        conexao, endereco = servidor.accept()
        clientes.append(conexao)
        threading.Thread(target=gerenciar_cliente, args=(conexao, endereco)).start()

iniciar_servidor()
